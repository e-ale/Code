#include <stdio.h>

int *a;

void a_badidea(void);

int main(int argc, char *argv[])
{
	a_badidea();
	printf("Hello World!\n");
	return(0);
}

void a_badidea(void)
{
	int z = 16;
	*a = z;
}
